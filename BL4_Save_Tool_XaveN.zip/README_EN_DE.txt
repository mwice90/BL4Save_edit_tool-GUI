BL4 Save Tool — GUI + Surgical Patcher
Coded By XaveN...(fürOPA WO.WI)

[EN] Overview
This package contains a Borderlands 4 save editor with a GUI that performs surgical edits on decrypted YAML and re‑packs via the official CLI (recommended). It preserves the save structure to avoid corruption.

Included
- bl4-save-tool-gui.exe  (GUI editor)
- scripts/entry_blxsave_gui.py (GUI source)
- scripts/bl4_save_editor.py   (optional CLI editor)
- steamid.txt (template; put your SteamID64 here)

Not included
- bl4-crypt-cli.exe — Please download/place your official CLI next to the EXE, or select it via the GUI (“Find CLI”). Using the official CLI ensures the exact game packing (zlib + PKCS7 + layout).

Prerequisites
- Windows, Python NOT required for using the GUI EXE.
- Your SteamID64 (17 digits, starts with 7656119...).

[EN] Quick Start (GUI)
1) Copy bl4-save-tool-gui.exe to a folder of your choice.
2) Place bl4-crypt-cli-*.exe in the same folder (recommended), or use the GUI’s “Find CLI”.
3) Create a steamid.txt in the same folder (optional) with your SteamID64, or fill it in the GUI.
4) Click “Load Info” to preview values from a .sav (or .yaml).
5) Change Level, Cash, Eridium, Character Skill Points, Specialization Tokens, Echo Tokens as needed.
6) Click “Write .sav” to produce the edited save.
7) Back up your original save and copy the edited .sav into your game folder.

[EN] Notes
- The tool edits only specific lines and keeps unknown YAML tags/structure intact.
- Golden keys appear to be SHIFT/online-managed; not present as a simple local counter.
- Always disable cloud sync temporarily and back up before replacing files.

[DE] Übersicht
Dieses Paket enthält einen Borderlands‑4‑Save‑Editor mit GUI. Er führt chirurgische Änderungen am entschlüsselten YAML durch und verpackt anschließend über das offizielle CLI (empfohlen). So bleibt die Save‑Struktur erhalten und Beschädigungen werden vermieden.

Enthalten
- bl4-save-tool-gui.exe  (GUI‑Editor)
- scripts/entry_blxsave_gui.py (GUI‑Quellcode)
- scripts/bl4_save_editor.py   (optionale CLI‑Variante)
- steamid.txt (Vorlage; hier deine SteamID64 eintragen)

Nicht enthalten
- bl4-crypt-cli.exe — Bitte lade/lege dein offizielles CLI neben die EXE oder wähle es in der GUI („Find CLI“). Das offizielle Tool sorgt für exakt das Game‑Format (zlib + PKCS7 + Layout).

Voraussetzungen
- Windows, Python ist für die GUI‑EXE nicht erforderlich.
- Deine SteamID64 (17 Stellen, beginnt mit 7656119...).

[DE] Schnellanleitung (GUI)
1) Kopiere bl4-save-tool-gui.exe in einen Ordner deiner Wahl.
2) Lege bl4-crypt-cli-*.exe in denselben Ordner (empfohlen) oder wähle es per „Find CLI“ aus.
3) Erstelle optional eine steamid.txt im selben Ordner mit deiner SteamID64 oder trage sie in der GUI ein.
4) Klicke „Load Info“, um Werte aus einer .sav (oder .yaml) anzuzeigen.
5) Ändere Level, Cash, Eridium, Charakter‑Skillpunkte, Spezialisierungs‑Tokens, Echo‑Tokens nach Bedarf.
6) Klicke „Write .sav“, um die bearbeitete Save zu erzeugen.
7) Sichere deine originale Save und kopiere die bearbeitete .sav in deinen Spiel‑Ordner.

[EN/DE] Advanced (optional CLI)
- Show:  python scripts/bl4_save_editor.py show -i "path\\1.sav" -s STEAMID64
- Set:   python scripts/bl4_save_editor.py set -i "path\\1.sav" -o "path\\1.edited.sav" -s STEAMID64 --cash 99999999 --eridium 3000 --level 50

Safety
- Always back up saves. Close the game and temporarily disable cloud sync before replacing files.

Signature
Coded By XaveN...(fürOPA WO.WI)
