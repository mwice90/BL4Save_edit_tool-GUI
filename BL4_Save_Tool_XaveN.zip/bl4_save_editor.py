#!/usr/bin/env python3

"""
Borderlands 4 Save Editor (minimal)

Features
- Decrypt a .sav to YAML (in-memory) using embedded base key + SteamID64.
- Show key info (name, class, level, currencies, bank count if present).
- Modify currencies (cash, eridium) and re-encrypt back to .sav.

Usage examples
- Show from .sav (auto-decrypt):
  python scripts/bl4_save_editor.py show -i "C:/path/1.sav" -s 7656119...

- Set cash/eridium and write a new .sav:
  python scripts/bl4_save_editor.py set -i "C:/path/1.sav" -o "C:/path/1.edited.sav" -s 7656119... --cash 9999999 --eridium 12345

Notes
- If -s/--steamid is omitted for .sav inputs, the tool tries steamid.txt in cwd.
- For .yaml inputs, steamid is not required unless you output a .sav.
"""

from __future__ import annotations

import argparse
import sys
import zlib
from pathlib import Path
from typing import Any, Dict, Tuple

try:
    from Crypto.Cipher import AES  # type: ignore
    from Crypto.Util.Padding import pad, unpad  # type: ignore
except Exception as e:  # pragma: no cover
    print("error: missing dependency pycryptodome (Crypto). Install with:\n  python -m pip install --user pycryptodome", file=sys.stderr)
    sys.exit(1)

try:
    import yaml  # type: ignore
    from yaml.loader import SafeLoader  # type: ignore
    from yaml.nodes import MappingNode, ScalarNode, SequenceNode  # type: ignore
except Exception:
    print("error: missing dependency PyYAML (yaml). Install with:\n  python -m pip install --user pyyaml", file=sys.stderr)
    sys.exit(1)


# Base AES key provided by the user (constant), 32 bytes
BASE_KEY = bytes(
    (
        0x35,
        0xEC,
        0x33,
        0x77,
        0xF3,
        0x5D,
        0xB0,
        0xEA,
        0xBE,
        0x6B,
        0x83,
        0x11,
        0x54,
        0x03,
        0xEB,
        0xFB,
        0x27,
        0x25,
        0x64,
        0x2E,
        0xD5,
        0x49,
        0x06,
        0x29,
        0x05,
        0x78,
        0xBD,
        0x60,
        0xBA,
        0x4A,
        0xA7,
        0x87,
    )
)


def derive_key(steamid64: str) -> bytes:
    # digits only, little-endian 8 bytes
    sid = int("".join(ch for ch in steamid64 if ch.isdigit()), 10)
    sid_le = sid.to_bytes(8, "little", signed=False)
    k = bytearray(BASE_KEY)
    for i in range(8):
        k[i] ^= sid_le[i]
    return bytes(k)


def decrypt_sav_to_yaml_bytes(sav_bytes: bytes, key: bytes) -> bytes:
    if len(sav_bytes) % 16 != 0:
        raise ValueError(f"input .sav size {len(sav_bytes)} not multiple of 16")
    pt_padded = AES.new(key, AES.MODE_ECB).decrypt(sav_bytes)
    try:
        body = unpad(pt_padded, 16, style="pkcs7")
    except ValueError:
        # Some versions might be no-padding; keep raw
        body = pt_padded
    return zlib.decompress(body)


def encrypt_yaml_bytes_to_sav(yaml_bytes: bytes, key: bytes) -> bytes:
    comp = zlib.compress(yaml_bytes, level=9)
    pt_padded = pad(comp, 16, style="pkcs7")
    return AES.new(key, AES.MODE_ECB).encrypt(pt_padded)


class _IgnoreUnknownTagsLoader(SafeLoader):
    pass


def _unknown_tag_constructor(loader: SafeLoader, tag_suffix: str, node):  # type: ignore[no-redef]
    # Convert unknown tagged nodes into plain Python constructs.
    if isinstance(node, ScalarNode):
        return loader.construct_scalar(node)
    if isinstance(node, SequenceNode):
        return loader.construct_sequence(node)
    if isinstance(node, MappingNode):
        return loader.construct_mapping(node)
    return None


yaml.add_multi_constructor("!", _unknown_tag_constructor, Loader=_IgnoreUnknownTagsLoader)


def _safe_yaml_load(data: bytes) -> Dict[str, Any]:
    obj = yaml.load(data, Loader=_IgnoreUnknownTagsLoader)
    if not isinstance(obj, dict):
        raise SystemExit("error: unexpected YAML structure; expected mapping at root")
    return obj


def load_yaml_from_input(input_path: Path, steamid: str | None) -> Tuple[Dict[str, Any], bytes | None, bytes | None]:
    """Returns (data, original_yaml_bytes, sav_key) where original_yaml_bytes is None if source was .sav.
    sav_key is the AES key if source was .sav, else None.
    """
    if input_path.suffix.lower() == ".sav":
        if not steamid:
            # try steamid.txt in CWD
            sid_file = Path("steamid.txt")
            if sid_file.exists():
                steamid = sid_file.read_text(encoding="utf-8").strip()
        if not steamid:
            raise SystemExit("error: SteamID64 required for .sav input (use -s/--steamid or steamid.txt)")
        key = derive_key(steamid)
        yaml_bytes = decrypt_sav_to_yaml_bytes(input_path.read_bytes(), key)
        data = _safe_yaml_load(yaml_bytes)
        return data, None, key
    else:
        yaml_bytes = input_path.read_bytes()
        data = _safe_yaml_load(yaml_bytes)
        return data, yaml_bytes, None


def dump_yaml(data: Dict[str, Any]) -> bytes:
    txt = yaml.safe_dump(data, sort_keys=False, allow_unicode=True)
    return txt.encode("utf-8")


def show_info(data: Dict[str, Any]) -> str:
    s = data.get("state", {}) if isinstance(data.get("state"), dict) else {}

    # Character basic
    char_name = s.get("char_name")
    char_class = s.get("class")
    difficulty = s.get("player_difficulty")

    # Level info
    level = None
    spec_level = None
    exp = s.get("experience")
    if isinstance(exp, list):
        for e in exp:
            if isinstance(e, dict) and e.get("type") == "Character":
                level = e.get("level")
            if isinstance(e, dict) and e.get("type") == "Specialization":
                spec_level = e.get("level")

    # Currencies
    cur = s.get("currencies", {}) if isinstance(s.get("currencies"), dict) else {}
    cash = cur.get("cash")
    eridium = cur.get("eridium")

    # Bank info (if this is a profile.yaml structure)
    bank_count = None
    domains = data.get("domains")
    if isinstance(domains, dict):
        shared = domains.get("local", {}).get("shared", {}) if isinstance(domains.get("local"), dict) else {}
        inv = shared.get("inventory", {}) if isinstance(shared, dict) else {}
        items = inv.get("items", {}) if isinstance(inv, dict) else {}
        bank = items.get("bank") if isinstance(items, dict) else None
        if isinstance(bank, dict):
            bank_count = sum(1 for k in bank.keys() if str(k).startswith("slot_"))

    lines = []
    if char_name is not None:
        lines.append(f"Character: {char_name}")
    if char_class is not None:
        lines.append(f"Class: {char_class}")
    if difficulty is not None:
        lines.append(f"Difficulty: {difficulty}")
    if level is not None:
        lines.append(f"Level: {level}")
    if spec_level is not None:
        lines.append(f"Specialization Level: {spec_level}")
    if cash is not None or eridium is not None:
        lines.append(f"Currencies: cash={cash} eridium={eridium}")
    if bank_count is not None:
        lines.append(f"Bank slots: {bank_count}")
    if not lines:
        lines.append("No standard character/profile fields recognized.")
    return "\n".join(lines)


def set_values(
    data: Dict[str, Any], cash: int | None, eridium: int | None, level: int | None
) -> None:
    state = data.get("state")
    if not isinstance(state, dict):
        raise SystemExit("error: could not find 'state' section in YAML to set values")
    curr = state.get("currencies")
    if not isinstance(curr, dict):
        curr = {}
        state["currencies"] = curr
    if cash is not None:
        curr["cash"] = int(cash)
    if eridium is not None:
        curr["eridium"] = int(eridium)
    if level is not None:
        # Update character level within state.experience list
        exp = state.get("experience")
        if isinstance(exp, list):
            updated = False
            for e in exp:
                if isinstance(e, dict) and e.get("type") == "Character":
                    e["level"] = int(level)
                    updated = True
            if not updated:
                exp.append({"type": "Character", "level": int(level), "points": 0})
        else:
            state["experience"] = [
                {"type": "Character", "level": int(level), "points": 0}
            ]


def parse_args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="bl4-save-editor",
        description="Decrypt, show, modify and re-encrypt Borderlands 4 saves",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    p_show = sub.add_parser("show", help="Show key info from .sav/.yaml")
    p_show.add_argument("-i", "--input", required=True, help="Input .sav or .yaml")
    p_show.add_argument("-s", "--steamid", help="SteamID64 (required for .sav input)")

    p_set = sub.add_parser("set", help="Set values and optionally re-encrypt to .sav")
    p_set.add_argument("-i", "--input", required=True, help="Input .sav or .yaml")
    p_set.add_argument("-o", "--output", help="Output path (.sav or .yaml). If omitted, overwrites input type")
    p_set.add_argument("-s", "--steamid", help="SteamID64 (required for .sav input or .sav output)")
    p_set.add_argument("--cash", type=int, help="Set cash amount")
    p_set.add_argument("--eridium", type=int, help="Set eridium amount")
    p_set.add_argument("--level", type=int, help="Set character level")

    return p.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    in_path = Path(args.input)
    steamid: str | None = getattr(args, "steamid", None)

    if args.cmd == "show":
        data, _, _ = load_yaml_from_input(in_path, steamid)
        print(show_info(data))
        return 0

    if args.cmd == "set":
        data, orig_yaml_bytes, sav_key = load_yaml_from_input(in_path, steamid)

        # apply edits
        if args.cash is None and args.eridium is None and args.level is None:
            print("warning: no changes specified; nothing to do", file=sys.stderr)
        else:
            set_values(data, args.cash, args.eridium, args.level)

        # decide output
        out_path: Path
        if args.output:
            out_path = Path(args.output)
        else:
            # overwrite same type by default
            out_path = in_path

        if out_path.suffix.lower() == ".sav":
            # need a key
            if sav_key is None:
                # need to derive using steamid
                if not steamid:
                    sid_file = Path("steamid.txt")
                    if sid_file.exists():
                        steamid = sid_file.read_text(encoding="utf-8").strip()
                if not steamid:
                    raise SystemExit("error: SteamID64 required to write .sav (use -s/--steamid or steamid.txt)")
                key = derive_key(steamid)
            else:
                key = sav_key

            yaml_bytes = dump_yaml(data)
            sav_bytes = encrypt_yaml_bytes_to_sav(yaml_bytes, key)
            out_path.write_bytes(sav_bytes)
            print(f"wrote {out_path}")
        else:
            yaml_bytes = dump_yaml(data)
            out_path.write_bytes(yaml_bytes)
            print(f"wrote {out_path}")
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
