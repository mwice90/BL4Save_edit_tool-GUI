#!/usr/bin/env python3

import os
import re
import zlib
import subprocess
import tempfile
import tkinter as tk
from tkinter import ttk
from tkinter import filedialog, messagebox
from pathlib import Path

try:
    from Crypto.Cipher import AES  # type: ignore
    from Crypto.Util.Padding import pad, unpad  # type: ignore
except Exception:
    messagebox.showerror("Dependency missing", "pycryptodome not installed. Run: python -m pip install --user pycryptodome")
    raise


BASE_KEY = bytes(
    (
        0x35,
        0xEC,
        0x33,
        0x77,
        0xF3,
        0x5D,
        0xB0,
        0xEA,
        0xBE,
        0x6B,
        0x83,
        0x11,
        0x54,
        0x03,
        0xEB,
        0xFB,
        0x27,
        0x25,
        0x64,
        0x2E,
        0xD5,
        0x49,
        0x06,
        0x29,
        0x05,
        0x78,
        0xBD,
        0x60,
        0xBA,
        0x4A,
        0xA7,
        0x87,
    )
)


def derive_key(steamid64: str) -> bytes:
    sid = int("".join(ch for ch in steamid64 if ch.isdigit()), 10)
    sid_le = sid.to_bytes(8, "little", signed=False)
    k = bytearray(BASE_KEY)
    for i in range(8):
        k[i] ^= sid_le[i]
    return bytes(k)


def _detect_cli() -> Path | None:
    candidates = [
        Path.cwd() / 'bl4-crypt-cli.exe',
        Path.cwd() / 'bl4-crypt-cli-38-1-0-3-1757992118.exe',
        Path('C:/Users/Arbeit Xa/Documents/COde X/bl4-crypt-cli-38-1-0-3-1757992118.exe'),
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def decrypt_sav_to_text(sav_bytes: bytes, key: bytes) -> str:
    if len(sav_bytes) % 16 != 0:
        raise ValueError(".sav size not multiple of 16")
    pt_padded = AES.new(key, AES.MODE_ECB).decrypt(sav_bytes)
    try:
        body = unpad(pt_padded, 16, style="pkcs7")
    except ValueError:
        body = pt_padded
    raw = zlib.decompress(body)
    # Keep original line-endings; do not normalize
    text = raw.decode("utf-8", errors="replace")
    return text


def encrypt_text_to_sav(text: str, key: bytes) -> bytes:
    comp = zlib.compress(text.encode("utf-8"), level=9)
    pt = pad(comp, 16, style="pkcs7")
    return AES.new(key, AES.MODE_ECB).encrypt(pt)


def extract_info(text: str) -> dict:
    info = {}
    # Character block
    m_name = re.search(r"(?m)^\s*char_name:\s*(.+)$", text)
    if m_name:
        info["char_name"] = m_name.group(1).strip()
    m_class = re.search(r"(?m)^\s*class:\s*(.+)$", text)
    if m_class:
        info["class"] = m_class.group(1).strip()
    # Level: prefer Character block level
    m_lvl = re.search(r"(?ms)-\s*type:\s*Character\s*\n\s*level:\s*(\d+)", text)
    if m_lvl:
        info["level"] = int(m_lvl.group(1))
    # Currencies
    m_cash = re.search(r"(?m)^\s*cash:\s*(\d+)\b", text)
    if m_cash:
        info["cash"] = int(m_cash.group(1))
    m_eri = re.search(r"(?m)^\s*eridium:\s*(\d+)\b", text)
    if m_eri:
        info["eridium"] = int(m_eri.group(1))
    # point_pools
    m_cp = re.search(r"(?m)^\s*characterprogresspoints:\s*(\d+)\b", text)
    if m_cp:
        info["characterprogresspoints"] = int(m_cp.group(1))
    m_sp = re.search(r"(?m)^\s*specializationtokenpool:\s*(\d+)\b", text)
    if m_sp:
        info["specializationtokenpool"] = int(m_sp.group(1))
    m_ep = re.search(r"(?m)^\s*echotokenprogresspoints:\s*(\d+)\b", text)
    if m_ep:
        info["echotokenprogresspoints"] = int(m_ep.group(1))
    return info


def patch_values(text: str, *, level=None, cash=None, eridium=None, cpp=None, stp=None, etp=None) -> str:
    working = text

    def sub_once(pat, repl):
        nonlocal working
        working, _ = re.subn(pat, repl, working, count=1, flags=re.M)

    # Cash/Eridium: replace first occurrence lines (under currencies)
    if cash is not None:
        sub_once(r"^(\s*cash:\s*)\d+\b", rf"\g<1>{int(cash)}")
    if eridium is not None:
        sub_once(r"^(\s*eridium:\s*)\d+\b", rf"\g<1>{int(eridium)}")

    # Level: Character block: either replace existing or insert before points line
    if level is not None:
        # try replace existing level first
        new, n = re.subn(r"(?ms)(^[ \t]*-\s*type:\s*Character\s*\n)([ \t]*level:\s*)\d+\b",
                         rf"\g<1>\g<2>{int(level)}", working, count=1)
        if n == 0:
            # insert before points
            def repl(m):
                head = m.group(1)
                pts = m.group(2)
                indent = " " * 4
                return head + f"{indent}level: {int(level)}\n" + pts

            new, n = re.subn(r"(?ms)(^[ \t]*-\s*type:\s*Character\s*\n)(?:.*?\n)?([ \t]*points:\s*\d+\b)", repl, working, count=1)
        working = new

    # point_pools block replacements scoped under its indentation
    m = re.search(r"(?m)^(?P<ind>[ \t]*)point_pools:\s*\n(?P<body>(?:^(?P=ind)[ \t]+.*\n)+)", working)
    if m:
        ind = m.group("ind") + "  "
        body = m.group("body")
        if cpp is not None:
            body = re.sub(rf"(?m)^({re.escape(ind)}characterprogresspoints:\s*)\d+\b", rf"\g<1>{int(cpp)}", body, count=1)
        if stp is not None:
            body = re.sub(rf"(?m)^({re.escape(ind)}specializationtokenpool:\s*)\d+\b", rf"\g<1>{int(stp)}", body, count=1)
        if etp is not None:
            body = re.sub(rf"(?m)^({re.escape(ind)}echotokenprogresspoints:\s*)\d+\b", rf"\g<1>{int(etp)}", body, count=1)
        working = working[: m.start("body")] + body + working[m.end("body") :]

    return working


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("BL4 Save Tool (GUI)")
        self.geometry("740x520")
        self.minsize(700, 480)

        # Paths + steamid
        self.in_var = tk.StringVar()
        self.out_var = tk.StringVar()
        self.steam_var = tk.StringVar(value=self._prefill_steamid())

        # Desired values
        self.level_var = tk.StringVar()
        self.cash_var = tk.StringVar()
        self.eri_var = tk.StringVar()
        self.cpp_var = tk.StringVar()
        self.stp_var = tk.StringVar()
        self.etp_var = tk.StringVar()

        # Top-level layout with labeled frames
        root = ttk.Frame(self)
        root.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Section: I/O
        io_frame = ttk.LabelFrame(root, text="Files")
        io_frame.pack(fill=tk.X, expand=False, padx=0, pady=6)

        ttk.Label(io_frame, text="Input (.sav/.yaml)").grid(row=0, column=0, sticky="w")
        ttk.Entry(io_frame, textvariable=self.in_var, width=56).grid(row=0, column=1, sticky="we")
        ttk.Button(io_frame, text="Browse", command=self._pick_in).grid(row=0, column=2, padx=4)

        ttk.Label(io_frame, text="Output (.sav)").grid(row=1, column=0, sticky="w")
        ttk.Entry(io_frame, textvariable=self.out_var, width=56).grid(row=1, column=1, sticky="we")
        ttk.Button(io_frame, text="Browse", command=self._pick_out).grid(row=1, column=2, padx=4)

        ttk.Label(io_frame, text="SteamID64").grid(row=2, column=0, sticky="w")
        ttk.Entry(io_frame, textvariable=self.steam_var, width=20).grid(row=2, column=1, sticky="w")

        self.cli_var = tk.StringVar(value=str(_detect_cli() or ''))
        ttk.Label(io_frame, text="bl4-crypt-cli (recommended)").grid(row=2, column=2, sticky="w")
        ttk.Button(io_frame, text="Find CLI", command=self._pick_cli).grid(row=2, column=3, padx=4, sticky="e")

        io_frame.columnconfigure(1, weight=1)

        # Section: Values
        val_frame = ttk.LabelFrame(root, text="Values")
        val_frame.pack(fill=tk.X, expand=False, padx=0, pady=6)

        ttk.Label(val_frame, text="Level").grid(row=0, column=0, sticky="e")
        ttk.Entry(val_frame, textvariable=self.level_var, width=10).grid(row=0, column=1, sticky="w")

        ttk.Label(val_frame, text="Cash").grid(row=0, column=2, sticky="e")
        ttk.Entry(val_frame, textvariable=self.cash_var, width=12).grid(row=0, column=3, sticky="w")

        ttk.Label(val_frame, text="Eridium").grid(row=0, column=4, sticky="e")
        ttk.Entry(val_frame, textvariable=self.eri_var, width=10).grid(row=0, column=5, sticky="w")

        ttk.Label(val_frame, text="Char SkillPts").grid(row=1, column=0, sticky="e")
        ttk.Entry(val_frame, textvariable=self.cpp_var, width=10).grid(row=1, column=1, sticky="w")

        ttk.Label(val_frame, text="Spec Tokens").grid(row=1, column=2, sticky="e")
        ttk.Entry(val_frame, textvariable=self.stp_var, width=12).grid(row=1, column=3, sticky="w")

        ttk.Label(val_frame, text="Echo Tokens").grid(row=1, column=4, sticky="e")
        ttk.Entry(val_frame, textvariable=self.etp_var, width=10).grid(row=1, column=5, sticky="w")

        for c in (1,3,5):
            val_frame.columnconfigure(c, weight=1)

        # Section: Actions
        act_frame = ttk.Frame(root)
        act_frame.pack(fill=tk.X, expand=False, padx=0, pady=6)
        ttk.Button(act_frame, text="Load Info", command=self._load_info).pack(side=tk.LEFT)
        ttk.Button(act_frame, text="Write .sav", command=self._write_sav).pack(side=tk.LEFT, padx=8)
        ttk.Button(act_frame, text="Help", command=self._show_help).pack(side=tk.LEFT)

        # Output box
        out_frame = ttk.LabelFrame(root, text="Output")
        out_frame.pack(fill=tk.BOTH, expand=True, padx=0, pady=6)
        self.out_text = tk.Text(out_frame, height=12)
        self.out_text.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)

        # Signature/footer
        sig = ttk.Label(root, text="Coded By XaveN...(fürOPA WO.WI)", anchor="e", foreground="#666")
        sig.pack(fill=tk.X, side=tk.BOTTOM)

    def _prefill_steamid(self) -> str:
        sid_file = Path("steamid.txt")
        if sid_file.exists():
            return sid_file.read_text(encoding="utf-8").strip()
        return ""

    def _pick_in(self):
        path = filedialog.askopenfilename(title="Choose input", filetypes=[("Saves/YAML", ".sav .yaml")])
        if path:
            self.in_var.set(path)
            if not self.out_var.get():
                out = Path(path).with_suffix("")  # remove suffix
                self.out_var.set(str(out) + ".edited.sav")

    def _pick_out(self):
        path = filedialog.asksaveasfilename(title="Save output .sav", defaultextension=".sav", filetypes=[("Saves", ".sav")])
        if path:
            self.out_var.set(path)

    def _pick_cli(self):
        path = filedialog.askopenfilename(title="Choose bl4-crypt-cli.exe", filetypes=[("Executable", ".exe")])
        if path:
            self.cli_var.set(path)

    def _use_cli(self) -> Path | None:
        p = Path(self.cli_var.get().strip())
        return p if p.exists() else None

    def _load_info(self):
        try:
            info = self._load_current_info()
            lines = [f"{k}: {v}" for k, v in info.items()]
            self._log("\n".join(lines) if lines else "No info found")
            # prefill fields
            if "level" in info:
                self.level_var.set(str(info["level"]))
            if "cash" in info:
                self.cash_var.set(str(info["cash"]))
            if "eridium" in info:
                self.eri_var.set(str(info["eridium"]))
            if "characterprogresspoints" in info:
                self.cpp_var.set(str(info["characterprogresspoints"]))
            if "specializationtokenpool" in info:
                self.stp_var.set(str(info["specializationtokenpool"]))
            if "echotokenprogresspoints" in info:
                self.etp_var.set(str(info["echotokenprogresspoints"]))
        except Exception as e:
            messagebox.showerror("Load error", str(e))

    def _write_sav(self):
        try:
            in_path = Path(self.in_var.get())
            out_path = Path(self.out_var.get())
            steamid = self.steam_var.get().strip()
            if not in_path.exists():
                raise RuntimeError("Input file does not exist")
            if in_path.suffix.lower() not in (".sav", ".yaml"):
                raise RuntimeError("Input must be .sav or .yaml")
            if out_path.suffix.lower() != ".sav":
                raise RuntimeError("Output must be .sav")
            if not steamid:
                raise RuntimeError("SteamID64 required")
            key = derive_key(steamid)

            # Read text (decrypt if .sav). Prefer official CLI to preserve format nuances
            cli = self._use_cli()
            if in_path.suffix.lower() == ".sav":
                if cli:
                    with tempfile.TemporaryDirectory() as td:
                        tmp_yaml = Path(td) / "tmp.yaml"
                        cmd = [
                            str(cli),
                            "decrypt",
                            "-i",
                            str(in_path),
                            "-o",
                            str(tmp_yaml),
                            "-s",
                            steamid,
                            "--key-hex",
                            BASE_KEY.hex().upper(),
                        ]
                        subprocess.run(cmd, check=True)
                        text = tmp_yaml.read_text(encoding="utf-8")
                else:
                    text = decrypt_sav_to_text(in_path.read_bytes(), key)
            else:
                text = in_path.read_text(encoding="utf-8")

            # Patch based on filled fields
            lv = self._to_int(self.level_var.get())
            cash = self._to_int(self.cash_var.get())
            eri = self._to_int(self.eri_var.get())
            cpp = self._to_int(self.cpp_var.get())
            stp = self._to_int(self.stp_var.get())
            etp = self._to_int(self.etp_var.get())
            new_text = patch_values(text, level=lv, cash=cash, eridium=eri, cpp=cpp, stp=stp, etp=etp)

            # Preserve original newline style
            newline = "\r\n" if "\r\n" in text else ("\r" if "\r" in text and "\n" not in text else "\n")

            # Encrypt and write. Prefer official CLI if available
            if cli:
                with tempfile.TemporaryDirectory() as td:
                    tmp_yaml = Path(td) / "tmp.yaml"
                    tmp_yaml.write_text(new_text.replace("\n", newline), encoding="utf-8", newline="")
                    cmd = [
                        str(cli),
                        "encrypt",
                        "-i",
                        str(tmp_yaml),
                        "-o",
                        str(out_path),
                        "-s",
                        steamid,
                        "--key-hex",
                        BASE_KEY.hex().upper(),
                    ]
                    subprocess.run(cmd, check=True)
            else:
                out_bytes = encrypt_text_to_sav(new_text.replace("\n", newline), key)
                out_path.write_bytes(out_bytes)
            self._log(f"Wrote {out_path}")

        except Exception as e:
            messagebox.showerror("Write error", str(e))

    def _to_int(self, s: str):
        s = (s or "").strip()
        return int(s) if s else None

    def _load_current_info(self) -> dict:
        in_path = Path(self.in_var.get())
        steamid = self.steam_var.get().strip()
        if not in_path.exists():
            raise RuntimeError("Input file does not exist")
        if in_path.suffix.lower() == ".sav":
            if not steamid:
                raise RuntimeError("SteamID64 required for .sav")
            key = derive_key(steamid)
            text = decrypt_sav_to_text(in_path.read_bytes(), key)
        else:
            text = in_path.read_text(encoding="utf-8")
        return extract_info(text)

    def _log(self, msg: str):
        self.out_text.delete("1.0", tk.END)
        self.out_text.insert(tk.END, msg + "\n")

    def _show_help(self):
        help_text = (
            "BL4 Save Tool (GUI)\n\n"
            "What this tool does:\n"
            "- Decrypts a Borderlands 4 .sav (using your SteamID64 + base key).\n"
            "- Patches only specific YAML lines (cash, eridium, level, point pools).\n"
            "- Re-encrypts the file exactly as the game expects.\n\n"
            "Best results:\n"
            "- Click 'Find CLI' and select your bl4-crypt-cli.exe so the app uses the official packer.\n"
            "- Enter your SteamID64 (or place it in steamid.txt).\n"
            "- Use 'Load Info' to preview values, then 'Write .sav' to save.\n\n"
            "Notes:\n"
            "- Only minimal text changes are made; other YAML structure/tags remain untouched.\n"
            "- Always back up your saves before editing.\n"
            "- Golden keys are likely SHIFT/online-managed and may not exist as a local counter.\n\n"
            "Signature: Coded By XaveN...(fürOPA WO.WI)"
        )
        messagebox.showinfo("Help", help_text)


if __name__ == "__main__":
    App().mainloop()
